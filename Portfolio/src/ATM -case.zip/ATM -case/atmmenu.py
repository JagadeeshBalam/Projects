#atmmenu.py---------------file name and acts as module name.
def atmmenu():
    print("="*50)
    print("\tATM OPERATIONS")
    print("="*50)
    print("\t1.Deposit")
    print("\t2.Withdraw")
    print("\t3.Balance Enquiry")
    print("\t4.Exit")
    print("="*50)
